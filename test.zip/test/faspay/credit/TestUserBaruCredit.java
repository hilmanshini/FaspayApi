/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package faspay.credit;

import faspayapi.credit.FaspayUserCredit;

/**
 *
 * @author hilmananwarsah
 */
public class TestUserBaruCredit extends FaspayUserCredit{

    public TestUserBaruCredit() {
        setMerchantId("test_migs_f3ds");
        setPass("abcde");
    }
    
    
    
}
